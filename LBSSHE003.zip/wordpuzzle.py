import enum
import copy
import random

# Grid is assumed to have top left origin.
# Up is -ve y, Down is +ve y.
# Left is -ve x, Right is +ve x.


def duplicate(grid):
    return copy.deepcopy(grid)

#directions
class Direction(enum.Enum):
    Up = (0, -1)
    Down = (0, 1)
    Right = (1, 0)
    Left = (-1, 0)
    UpRight = (1, -1)
    UpLeft = (-1, -1)
    DownRight = (1, 1)
    DownLeft = (-1, 1)

#player move
def move(i, j,  direction):
    return i+direction.value[0], j+direction.value[1]


def insert(grid, location, word):
    i = location[0]
    j = location[1]
    direction = location[2]

    for letter in word:
        grid[j][i] = letter
        i, j = move(i, j, direction)


def test(grid, width, height, i, j, direction, word):
    if direction in {Direction.Up, Direction.UpRight, Direction.UpLeft} and j < len(word)-1:
        return False
    elif direction in {Direction.Down, Direction.DownRight, Direction.DownLeft} and j+len(word) >= height:
        return False
    elif direction in {Direction.Left, Direction.UpLeft, Direction.DownLeft} and i < len(word)-1:
        return False
    elif direction in {Direction.Right, Direction.UpRight, Direction.DownRight} and i+len(word) >= width:
        return False
    else:
        for letter in word:
            if grid[j][i] and not grid[j][i] == letter:
                return False
            else:
                i, j = move(i, j, direction)
        return True


def get_candidate_locations(grid, width, height, word):
    locations = []
    for i in range(width):
        for j in range(height):
            for direction in Direction:
                if test(grid, width, height, i, j, direction, word):
                    locations.append((i, j, direction))
    return locations


def fit(grid, width, height, words):
    if not words:
        return grid, []
    else:
        word = words[0]
        words = words[1:]
        locations = get_candidate_locations(grid, width, height, word)
        if not locations:
            return None, None
        else:
            random.shuffle(locations)
            for location in locations:
                result = duplicate(grid)
                insert(result, location, word)

                result, placements = fit(result, width, height, words)
                if result:
                    placements.append((location[0], location[1], location[2].name.lower(), word))
                    return result, placements

            return None, None

#random letter padding
def pad(grid, width, height):
    for i in range(width):
        for j in range(height):
            if not grid[i][j]:
                grid[i][j] = random.choice('abcdefghijklmnopqrstuvwxyz')

#get the max length words
def max_word(words):
    result = len(words[0])
    for word in words[1:]:
        if len(word)>result:
            result = len(word)
    return result

#build the puzzle
def build(width, height, words):
    if max_word(words)>width or max_word(words)<height:
        raise ValueError
    else:
        result, solutions =  fit([[None for i in range(width)] for j in range(height)], width, height, words)
        if result:
            pad(result, width, height)
            return result, solutions
        else:
            raise ValueError