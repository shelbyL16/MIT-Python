import game

# Test harness
puzzle, answers = build(6, 6, game_word)
if puzzle:
    for row in puzzle:
        for column in row:
           if column:
               print(column, end='')
           else:
               print(' ', end='')
        print()
    for answer in answers:
        print(answer)