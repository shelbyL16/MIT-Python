import morse_utils

def code_for(letter):
    morse=""
    
    if letter == "A" or letter == "a":
        morse = ".-"
        
    if letter == "B" or letter == "b":
        morse = "-..."
        
    if letter == "C" or letter == "c":
            morse = "-.-."    

    if letter == "D" or letter == "d":
            morse = "-.."    

    if letter == "E" or letter == "e":
            morse = "."    

    if letter == "F" or letter == "f":
            morse = "..-."  
    
    if letter == "G" or letter == "g":
            morse = "--."    
            
    if letter == "H" or letter == "h":
            morse = "...." 
    
    if letter == "I" or letter == "i":
            morse = ".." 
    
    if letter == "J" or letter == "j":
            morse = ".---"     

    if letter == "K" or letter == "k":
            morse = "-.-"     

    if letter == "L" or letter == "l":
            morse = ".-.."         

    if letter == "M" or letter == "m":
            morse = "--"     
           
    if letter == "N" or letter == "n":
        morse = "-."                                             
        
    if letter == "O" or letter == "o":
        morse = "---"                                                     
    
    if letter == "P" or letter == "p":
        morse = ".--."                                                             
           
    if letter == "Q" or letter == "q":
        morse = "--.-"                                                                     

    if letter == "R" or letter == "r":
        morse = ".-."   
        
    if letter == "S" or letter == "s":
        morse = "..."
    
    if letter == "T" or letter == "t":
        morse = "-"                                                                                             
        
    if letter == "U" or letter == "u":
        morse = "..-"  
            
    if letter == "V" or letter == "v":
        morse = "...-" 
        
    if letter == "W" or letter == "w":
        morse = ".--"  
        
    if letter == "X" or letter == "x":
        morse = "-..-"
        
    if letter == "Y" or letter == "y":
        morse = "-.--"    
        
    if letter == "Z" or letter == "z":
        morse = "--.."        
        
    return morse


#dash (pause for duration of a dot) dot (pause for duration of a dot) 
#dash (pause for duration of a dot) dot' and it will simultaneously print text
#'-^.^-^.'. = -.-.
def transmit_letter(letter):
    #get the morse letter
    morse=""
    morse= code_for(letter)
    answer = ""
    duration = int(0.1)
    frequency=1000

    for i in range (0,len(morse)):
    
        if i != len(morse)-1:
            ans = morse[i] +"^"  
            answer = answer+ans
            morse_utils.beep(frequency, duration)
        else:
            ans=morse[i]
            answer=answer+ans
            morse_utils.sleep(duration)
    
    print(answer, end = "")

def transmit_word(word):
    answer=""
    for i in range (0,len(word)):
        transmit_letter(word[i])
        if i != len(word)-1:
            print("|",end="")
    print(answer,end="")

#A function that prints two vertical bars and causes the program to pause (be silent) for the
#duration of 7 dots.
def word_pause():
    duration = int(0.1)
    for i in range(1,8):
        morse_utils.sleep(duration)
    ans="||"
    print(ans,end="")