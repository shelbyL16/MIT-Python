import wordpuzzle
import random

#variables
players=[] #players
score=[] #scores
file_words=[] #words in the file
game_word=[] #words in the game

def make():
  #open the file and read the lines in
  file = open("EnglishWords.txt", "r")
  for x in file:
    line = file.readline()
    file_words.append(line)
  
 
def create_words():
  #create a list of words after the start word 
  words=[]
  for i in range (0,len(file_words)):
    if i>=30:
      if len(file_words[i])<12:
        words.append(file_words[i])
  
  
  #get the random words
  for i in range (0,7):
    rand = random.randint(0,len(words))
    words[rand]= words[rand].replace('\n','')
    game_word.append(words[rand])
  
  #get the max length of the word and return it
  max_height_width=wordpuzzle.max_word(game_word)
  return max_height_width

def start():
  #Start the puzzle
  print("Welcome to the MIT Mega Puzzle \n")
  
  #number of players
  num_players = int(input("How many players?"))
  
  #get the players names
  for i in range(1,num_players+1):
      player_name = (input("Enter player " + str(i) + "'s name:"))
      players.append(player_name)
      score.append(0)

  
  print("Let's begin! Here's the puzzle:")
  print()

#When the players need to move
def move_player(answers):
  player_index = 0
  
  while len(answers) > 0:
    player_name = players[player_index]
    guess_raw = input(player_name + ", make a guess (x,y,direction,word): ")
    
    #if the players have quit
    if guess_raw=="quit" or guess_raw=="Quit":
      #return the final scores
      print()
      print("The final scores are:")
      for i in range(0,len(players)):
        print(players[i]," has ", score[i], "point(s)")
      #print answers not found
      print()
      print("You didnt find:")
      for ans in answers:
        print("'", ans[3], "' at (",ans[0],",",ans[1],")") 
      print("The game has ended :(")
      break
    else:
      guess = guess_raw.split(",")
      # Transform the guess into a tuple of the same format as the answers
      guess_tuple=[]
      guess_tuple = (int(guess[0]), int(guess[1]), guess[2], guess[3])
      # Check if the guess is correct
      if guess_tuple in answers:
        print("Congratulations, you found ", guess[3], "!")
        score[player_index]=score[player_index] + len(guess_tuple[3])
        print("That's ",len(guess[3]), " point(s)")
        print()
        answers.remove(guess_tuple)
      else:
        print("Unfortunately not a word in this puzzle")
        print()

    # Go to the next player
    player_index = (player_index + 1) % len(players)    

      
# Test harness
def main():
    make()
    max_height_width = create_words()
    start()
    puzzle, answers = wordpuzzle.build(max_height_width, max_height_width, game_word)
    if puzzle:
      i=0
      for t in range (0,max_height_width):
        print('{:>3d}'.format(t),end = "")
      print()
      for t in range (0,max_height_width):
        print("---",end = "")
      print()      
      for row in puzzle:
        print('{:<1d}'.format(i) ,end="|")
        for column in row:
          if column:
            s = '%s  ' %column
            print(s,end="")     
          else:
            print(' ', end='')
        i=i+1
        print()
    
    print()    
    print("Here are the answers for ease of testing - comment out if you dont want them :)")    
    for answer in answers:
      print(answer)
    print()
     
    move_player(answers)
if __name__ == '__main__':
    main()