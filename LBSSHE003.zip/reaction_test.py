#imports
import time
import random

def flush_input():
    try:
        import msvcrt        
        while msvcrt.kbhit():
            msvcrt.getch()
    except ImportError:
        import sys, termios
        termios.tcflush(sys.stdin, termios.TCIOFLUSH)



#Ask the user for the file and save input
file = input("Enter the name of the output file: \n")

while True:
    
    #Ask the user for their name and save input
    name = input("Enter subject name (or press 'enter' to quit): \n")
    if not name:
        break
    
    
    #Ask the user for test number
    tests = int(input("Enter the number of tests: \n"))
    takes=0.0
    takes=float(takes)
    
    for i in range(0,tests):
        wait_time =random.randint(0,5)
        print('Get ready...', flush=True)
        time.sleep(wait_time)
        start = time.time()
        print("Press 'enter' NOW!",flush=True)
        flush_input()
        input()
        end = time.time()
        taken = float(end) - float(start)
        print("Reaction time: ",str(round(taken,6)))
        takes = float(takes) + float(taken)
        
    average=takes/tests
    print("Tests complete.")
    print("Average reaction time: " , round(average,6))    
    print()
    
    with open(file, "a") as myfile:
        myfile.write("Average reaction time: " + str(round(average,6)) + "\n") 
        

